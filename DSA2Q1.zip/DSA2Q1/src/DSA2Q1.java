import java.util.Arrays;
public class DSA2Q1 {
	 public static int arrayPairSum(int[] nums) {
	        // Sort the array in ascending order
	        Arrays.sort(nums);

	        int maxSum = 0;
	        for (int i = 0; i < nums.length; i += 2) {
	            // Since the array is sorted, the minimum value in each pair will be the first element of the pair
	            maxSum += nums[i];
	        }

	        return maxSum;
	    }

	public static void main(String[] args) {
		   int[] nums = {1, 4, 3, 2};
	        int maxSum = arrayPairSum(nums);
	        System.out.println("Maximized sum: " + maxSum);
	}

}


