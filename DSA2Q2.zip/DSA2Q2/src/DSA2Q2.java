import java.util.HashSet;
public class DSA2Q2 {
	 public static int distributeCandies(int[] candyType) {
	        // Calculate the maximum number of unique candies Alice can eat
	        int maxCandies = candyType.length / 2;

	        // Use a HashSet to keep track of unique candy types
	        HashSet<Integer> uniqueCandies = new HashSet<>();

	        // Iterate over the candy types and add them to the HashSet
	        for (int candy : candyType) {
	            uniqueCandies.add(candy);

	            // If Alice has reached the maximum number of unique candies, she can stop eating more
	            if (uniqueCandies.size() == maxCandies) {
	                break;
	            }
	        }

	        // Return the number of unique candies Alice can eat
	        return uniqueCandies.size();
	    }

	public static void main(String[] args) {
		 int[] candyType = {1, 1, 2, 2, 3, 3};
	        int maxNumOfCandies = distributeCandies(candyType);
	        System.out.println("Maximum number of different types of candies Alice can eat: " + maxNumOfCandies);

	}

}



