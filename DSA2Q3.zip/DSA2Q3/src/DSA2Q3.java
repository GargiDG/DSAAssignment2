import java.util.HashMap;
public class DSA2Q3 {
	 public static int findLHS(int[] nums) {
	        // Create a HashMap to store the frequency of each number in the array
	        HashMap<Integer, Integer> frequencyMap = new HashMap<>();

	        // Populate the frequency map
	        for (int num : nums) {
	            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
	        }

	        int longestSubsequenceLength = 0;

	        // Iterate over the keys in the frequency map
	        for (int key : frequencyMap.keySet()) {
	            // Check if the map contains the number one greater than the current key
	            if (frequencyMap.containsKey(key + 1)) {
	                int currentSubsequenceLength = frequencyMap.get(key) + frequencyMap.get(key + 1);

	                // Update the longest subsequence length if necessary
	                longestSubsequenceLength = Math.max(longestSubsequenceLength, currentSubsequenceLength);
	            }
	        }

	        return longestSubsequenceLength;
	    }
	public static void main(String[] args) {
		 int[] nums = {1, 3, 2, 2, 5, 2, 3, 7};
	        int longestSubsequenceLength = findLHS(nums);
	        System.out.println("Length of the longest harmonious subsequence: " + longestSubsequenceLength);
	}

}



