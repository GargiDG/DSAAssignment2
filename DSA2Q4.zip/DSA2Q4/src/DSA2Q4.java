
public class DSA2Q4 {
	public static boolean canPlaceFlowers(int[] flowerbed, int n) {
        int count = 0;
        int i = 0;

        while (i < flowerbed.length) {
            if (flowerbed[i] == 0 && (i == 0 || flowerbed[i - 1] == 0) && (i == flowerbed.length - 1 || flowerbed[i + 1] == 0)) {
                // If the current plot is empty and the adjacent plots are also empty, we can plant a flower
                flowerbed[i] = 1;
                count++;
            }

            if (count >= n) {
                // If we have planted enough flowers, return true
                return true;
            }

            i++;
        }

        // If we reach the end of the flowerbed and haven't planted enough flowers, return false
        return false;
    }
	public static void main(String[] args) {
		 int[] flowerbed = {1, 0, 0, 0, 1};
	        int n = 1;
	        boolean canPlace = canPlaceFlowers(flowerbed, n);
	        System.out.println("Can place " + n + " flowers? " + canPlace);
	}

}

