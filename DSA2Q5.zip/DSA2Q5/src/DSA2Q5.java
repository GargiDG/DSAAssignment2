import java.util.Arrays;
public class DSA2Q5 {
	  public static int maximumProduct(int[] nums) {
	        // Sort the array in ascending order
	        Arrays.sort(nums);

	        int n = nums.length;
	        // The maximum product can be obtained by either multiplying the three largest numbers or
	        // multiplying the two smallest (negative) numbers with the largest number
	        int option1 = nums[n - 1] * nums[n - 2] * nums[n - 3];
	        int option2 = nums[0] * nums[1] * nums[n - 1];

	        // Return the maximum of the two options
	        return Math.max(option1, option2);
	    }

	public static void main(String[] args) {
		int[] nums = {1, 2, 3};
        int maxProduct = maximumProduct(nums);
        System.out.println("Maximum product: " + maxProduct);
	}

}



