import java.util.Arrays;
public class DSA2Q8 {
	public static int minimumScore(int[] nums, int k) {
        int n = nums.length;
        Arrays.sort(nums); // Sort the array in ascending order

        int minScore = nums[n - 1] - nums[0]; // Initialize the minimum score with the maximum difference

        for (int i = 0; i < n - 1; i++) {
            int minVal = nums[i] + k; // The minimum value that nums[i] can be changed to
            int maxVal = nums[i + 1] - k; // The maximum value that nums[i] can be changed to
            int currScore = Math.max(nums[n - 1] - k, maxVal) - Math.min(nums[0] + k, minVal);
            minScore = Math.min(minScore, currScore);
        }

        return minScore;
    }
	public static void main(String[] args) {
		 int[] nums = {1};
	        int k = 0;
	        int minScore = minimumScore(nums, k);
	        System.out.println("Minimum score: " + minScore);
	}

}



